<div class="container">
    <h1 class="mt-4">About Me</h1>
    <img src="<?= BASEURL; ?>/img/blnk.jpg" alt="wibisono adhi" width="200" class="rounded-circle shadow">
    <p>Halo, nama saya <?= $data['nama']; ?>,
        Umur saya <?= $data['umur']; ?>
        tahun, saya seorang <?= $data['pekerjaan']; ?></p>
</div>