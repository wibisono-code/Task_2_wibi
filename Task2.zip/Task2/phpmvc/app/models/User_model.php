<?php

class User_model
{
    private $nama = 'wibisono adhi';

    public function getUser()
    {
        return $this->nama;
    }
}
